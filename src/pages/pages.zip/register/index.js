import React from 'react';
import { Link } from 'react-router-dom'
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import './index.scss';
import { Images } from '../../assets/index';

function Register() {
  return (
    <>
      <div className="login-page">
        <div className="login-container">
          <div className="login-content">
            <div className="login-div">
              <div className="login">Register</div>
              <img src={Images.CloseIcon} className="close-img" />
            </div>
            <TextField label='Full Name' placeholder='sourabh' type='text' fulwidth required />
            <TextField label='Email Address' placeholder='sourabh.k@rejolut.com' fulwidth required />
            <TextField label='password' placeholder='*********' type='password' fulwidth required />
            <div className="checkbox-password">
            By registering you agree to our Terms & Conditions
            </div>
            <button type="Login" className="login-btn" fullwidth>Register</button>
            <div className="register-container">
              <button className="register-btn" fullwidth>Existing User? Log in</button>
              <div className="login-options">
                <div className="continue">Or Continue with</div>
                  <div className="google-image">
                    <img src={Images.GoogleIcon} className="google-img" />
                    <div className="google">Google</div>
                  </div>
                  <div className="google-image">
                    <img src={Images.FacebookIcon} className="google-img" />
                    <div className="google">Facebook</div>
                  </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </>
  );
}

export default Register;
