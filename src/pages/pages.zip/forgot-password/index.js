import React from 'react';
import { Images } from '../../assets/index';
import TextField from '@material-ui/core/TextField';
import './index.scss';

function ForgotPassword() {
    return (
        <div className="forgot-pass-page">
            <div className="forgot-pass-layout">
                <div className="forgot-pass-content-wrapper">
                    <div className="forgot-password-div" >Forgot Password</div>
                    <div className="msg">Don’t be panic, We are there for you.</div><br />
                    <p>Enter your email associated with your account and we will send a link to reset your password.</p>
                    <div className="field-container">
                        <TextField label="Enter Email" variant="outlined" name="email" />
                    </div>
                    <div className="btn-container">
                        <div className="btn">
                            <button>Submit</button>
                        </div>
                        <div className="redirect">
                            <div>Remember your password?</div>
                            <div className="login">Login</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default ForgotPassword;