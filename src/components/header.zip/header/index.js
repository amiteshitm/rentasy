import React, { Component } from 'react';
import { Link } from "react-router-dom";
import { Images } from '../../assets';

import './index.scss';

class Header extends Component {
    render() {
        return (
            <header className="header">
                <div className="site-branding">
                    <div className="renteasy-select-content">
                        <img src={Images.RenteasyIcon} className="renteasy-img" />
                        <div className="select-container">
                            <div className="select-type">Select Type</div>
                            <select>
                                <option>Rentals</option>
                            </select>
                        </div>
                    </div>
                    <div className="input-container">
                        <img src={Images.SearchIcon} className="search-img" />
                        <input type="text" placeholder="What would you like to rent?" />
                    </div>
                    <div className="location-container">
                        <img src={Images.LocationIcon} className="location-img" />
                        <div className="location-name">Toronto</div>
                        <img src={Images.DownarrowIcon} className="downarrow-img" />
                        
                    </div>
                    <div className="icons-container">
                        <img src={Images.HeartIcon} className="heart-img" />
                        <img src={Images.NotificationIcon} className="notification-img" />
                        <img src={Images.CartIcon} className="cart-img" />
                    </div>
                    <div className="login-register-container">Login / Register</div>
                </div>
            </header>
        );
    }
}

export default Header;






{/* <img alt={''} className="logo" src={'/logo512.png'} /> 
                    <nav className="menus">
                        <Link to={`/`}>Home</Link>
                        <Link to={`/account`}>Account</Link>
                        <Link to={`/login`}>Login </Link>
                        <Link to={`/register`}>Register</Link>
                    </nav> */}